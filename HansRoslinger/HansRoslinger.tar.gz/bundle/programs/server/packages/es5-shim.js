Package["core-runtime"].queue("es5-shim",function () {


/* Exports */
return {

}});
