Package["core-runtime"].queue("null",function () {/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
ReactiveVar = Package['reactive-var'].ReactiveVar;
ECMAScript = Package.ecmascript.ECMAScript;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
EmitterPromise = Package.meteor.EmitterPromise;
WebApp = Package.webapp.WebApp;
WebAppInternals = Package.webapp.WebAppInternals;
main = Package.webapp.main;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
meteorInstall = Package.modules.meteorInstall;
Promise = Package.promise.Promise;
Autoupdate = Package.autoupdate.Autoupdate;

var require = meteorInstall({"imports":{"api":{"links.ts":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// imports/api/links.ts                                                                   //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    module.export({
      LinksCollection: () => LinksCollection
    });
    let Mongo;
    module.link("meteor/mongo", {
      Mongo(v) {
        Mongo = v;
      }
    }, 0);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    const LinksCollection = new Mongo.Collection("links");
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.ts":function module(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                        //
// server/main.ts                                                                         //
//                                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////
                                                                                          //
!module.wrapAsync(async function (module, __reifyWaitForDeps__, __reify_async_result__) {
  "use strict";
  try {
    let Meteor;
    module.link("meteor/meteor", {
      Meteor(v) {
        Meteor = v;
      }
    }, 0);
    let LinksCollection;
    module.link("/imports/api/links", {
      LinksCollection(v) {
        LinksCollection = v;
      }
    }, 1);
    if (__reifyWaitForDeps__()) (await __reifyWaitForDeps__())();
    async function insertLink(_ref) {
      let {
        title,
        url
      } = _ref;
      await LinksCollection.insertAsync({
        title,
        url,
        createdAt: new Date()
      });
    }
    Meteor.startup(async () => {
      // If the Links collection is empty, add some data.
      if ((await LinksCollection.find().countAsync()) === 0) {
        await insertLink({
          title: "Do the Tutorial",
          url: "https://www.meteor.com/tutorials/react/creating-an-app"
        });
        await insertLink({
          title: "Follow the Guide",
          url: "https://guide.meteor.com"
        });
        await insertLink({
          title: "Read the Docs",
          url: "https://docs.meteor.com"
        });
        await insertLink({
          title: "Discussions",
          url: "https://forums.meteor.com"
        });
      }
      // We publish the entire Links collection to all clients.
      // In order to be fetched in real-time to the clients
      Meteor.publish("links", function () {
        return LinksCollection.find();
      });
    });
    __reify_async_result__();
  } catch (_reifyError) {
    return __reify_async_result__(_reifyError);
  }
  __reify_async_result__()
}, {
  self: this,
  async: false
});
////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".d.ts",
    ".d.ts.map",
    ".mjs",
    ".ts",
    ".tsx"
  ]
});


/* Exports */
return {
  require: require,
  eagerModulePaths: [
    "/server/main.ts"
  ]
}});

//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvbGlua3MudHMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLnRzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIkxpbmtzQ29sbGVjdGlvbiIsIk1vbmdvIiwibGluayIsInYiLCJfX3JlaWZ5V2FpdEZvckRlcHNfXyIsIkNvbGxlY3Rpb24iLCJfX3JlaWZ5X2FzeW5jX3Jlc3VsdF9fIiwiX3JlaWZ5RXJyb3IiLCJzZWxmIiwiYXN5bmMiLCJNZXRlb3IiLCJpbnNlcnRMaW5rIiwiX3JlZiIsInRpdGxlIiwidXJsIiwiaW5zZXJ0QXN5bmMiLCJjcmVhdGVkQXQiLCJEYXRlIiwic3RhcnR1cCIsImZpbmQiLCJjb3VudEFzeW5jIiwicHVibGlzaCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQUFBQSxNQUFBLENBQU9DLE1BQUUsQ0FBSztNQUFBQyxlQUFRLEVBQUFBLENBQUEsS0FBQUE7SUFBZTtJQUFBLElBQUFDLEtBQUE7SUFBQUgsTUFBQSxDQUFBSSxJQUFBO01BQUFELE1BQUFFLENBQUE7UUFBQUYsS0FBQSxHQUFBRSxDQUFBO01BQUE7SUFBQTtJQUFBLElBQUFDLG9CQUFBLFdBQUFBLG9CQUFBO0lBUzlCLE1BQU1KLGVBQWUsR0FBRyxJQUFJQyxLQUFLLENBQUNJLFVBQVUsQ0FBTyxPQUFPLENBQUM7SUFBQ0Msc0JBQUE7RUFBQSxTQUFBQyxXQUFBO0lBQUEsT0FBQUQsc0JBQUEsQ0FBQUMsV0FBQTtFQUFBO0VBQUFELHNCQUFBO0FBQUE7RUFBQUUsSUFBQTtFQUFBQyxLQUFBO0FBQUEsRzs7Ozs7Ozs7Ozs7Ozs7SUNUbkUsSUFBQUMsTUFBUztJQUFBWixNQUFRLENBQUFJLElBQUEsQ0FBTSxlQUFlLEVBQUM7TUFBQVEsT0FBQVAsQ0FBQTtRQUFBTyxNQUFBLEdBQUFQLENBQUE7TUFBQTtJQUFBO0lBQUEsSUFBQUgsZUFBQTtJQUFBRixNQUFBLENBQUFJLElBQUE7TUFBQUYsZ0JBQUFHLENBQUE7UUFBQUgsZUFBQSxHQUFBRyxDQUFBO01BQUE7SUFBQTtJQUFBLElBQUFDLG9CQUFBLFdBQUFBLG9CQUFBO0lBR3ZDLGVBQWVPLFVBQVVBLENBQUFDLElBQUEsRUFBNEM7TUFBQSxJQUEzQztRQUFFQyxLQUFLO1FBQUVDO01BQUcsQ0FBK0IsR0FBQUYsSUFBQTtNQUNuRSxNQUFNWixlQUFlLENBQUNlLFdBQVcsQ0FBQztRQUFFRixLQUFLO1FBQUVDLEdBQUc7UUFBRUUsU0FBUyxFQUFFLElBQUlDLElBQUk7TUFBRSxDQUFFLENBQUM7SUFDMUU7SUFFQVAsTUFBTSxDQUFDUSxPQUFPLENBQUMsWUFBVztNQUN4QjtNQUNBLElBQUksQ0FBQyxNQUFNbEIsZUFBZSxDQUFDbUIsSUFBSSxFQUFFLENBQUNDLFVBQVUsRUFBRSxNQUFNLENBQUMsRUFBRTtRQUNyRCxNQUFNVCxVQUFVLENBQUM7VUFDZkUsS0FBSyxFQUFFLGlCQUFpQjtVQUN4QkMsR0FBRyxFQUFFO1NBQ04sQ0FBQztRQUVGLE1BQU1ILFVBQVUsQ0FBQztVQUNmRSxLQUFLLEVBQUUsa0JBQWtCO1VBQ3pCQyxHQUFHLEVBQUU7U0FDTixDQUFDO1FBRUYsTUFBTUgsVUFBVSxDQUFDO1VBQ2ZFLEtBQUssRUFBRSxlQUFlO1VBQ3RCQyxHQUFHLEVBQUU7U0FDTixDQUFDO1FBRUYsTUFBTUgsVUFBVSxDQUFDO1VBQ2ZFLEtBQUssRUFBRSxhQUFhO1VBQ3BCQyxHQUFHLEVBQUU7U0FDTixDQUFDO01BQ0o7TUFFQTtNQUNBO01BQ0FKLE1BQU0sQ0FBQ1csT0FBTyxDQUFDLE9BQU8sRUFBRTtRQUN0QixPQUFPckIsZUFBZSxDQUFDbUIsSUFBSSxFQUFFO01BQy9CLENBQUMsQ0FBQztJQUNKLENBQUMsQ0FBQztJQUFDYixzQkFBQTtFQUFBLFNBQUFDLFdBQUE7SUFBQSxPQUFBRCxzQkFBQSxDQUFBQyxXQUFBO0VBQUE7RUFBQUQsc0JBQUE7QUFBQTtFQUFBRSxJQUFBO0VBQUFDLEtBQUE7QUFBQSxHIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gXCJtZXRlb3IvbW9uZ29cIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgTGluayB7XHJcbiAgX2lkPzogc3RyaW5nO1xyXG4gIHRpdGxlOiBzdHJpbmc7XHJcbiAgdXJsOiBzdHJpbmc7XHJcbiAgY3JlYXRlZEF0OiBEYXRlO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgTGlua3NDb2xsZWN0aW9uID0gbmV3IE1vbmdvLkNvbGxlY3Rpb248TGluaz4oXCJsaW5rc1wiKTtcclxuIiwiaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSBcIm1ldGVvci9tZXRlb3JcIjtcclxuaW1wb3J0IHsgTGluaywgTGlua3NDb2xsZWN0aW9uIH0gZnJvbSBcIi9pbXBvcnRzL2FwaS9saW5rc1wiO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gaW5zZXJ0TGluayh7IHRpdGxlLCB1cmwgfTogUGljazxMaW5rLCBcInRpdGxlXCIgfCBcInVybFwiPikge1xyXG4gIGF3YWl0IExpbmtzQ29sbGVjdGlvbi5pbnNlcnRBc3luYyh7IHRpdGxlLCB1cmwsIGNyZWF0ZWRBdDogbmV3IERhdGUoKSB9KTtcclxufVxyXG5cclxuTWV0ZW9yLnN0YXJ0dXAoYXN5bmMgKCkgPT4ge1xyXG4gIC8vIElmIHRoZSBMaW5rcyBjb2xsZWN0aW9uIGlzIGVtcHR5LCBhZGQgc29tZSBkYXRhLlxyXG4gIGlmICgoYXdhaXQgTGlua3NDb2xsZWN0aW9uLmZpbmQoKS5jb3VudEFzeW5jKCkpID09PSAwKSB7XHJcbiAgICBhd2FpdCBpbnNlcnRMaW5rKHtcclxuICAgICAgdGl0bGU6IFwiRG8gdGhlIFR1dG9yaWFsXCIsXHJcbiAgICAgIHVybDogXCJodHRwczovL3d3dy5tZXRlb3IuY29tL3R1dG9yaWFscy9yZWFjdC9jcmVhdGluZy1hbi1hcHBcIixcclxuICAgIH0pO1xyXG5cclxuICAgIGF3YWl0IGluc2VydExpbmsoe1xyXG4gICAgICB0aXRsZTogXCJGb2xsb3cgdGhlIEd1aWRlXCIsXHJcbiAgICAgIHVybDogXCJodHRwczovL2d1aWRlLm1ldGVvci5jb21cIixcclxuICAgIH0pO1xyXG5cclxuICAgIGF3YWl0IGluc2VydExpbmsoe1xyXG4gICAgICB0aXRsZTogXCJSZWFkIHRoZSBEb2NzXCIsXHJcbiAgICAgIHVybDogXCJodHRwczovL2RvY3MubWV0ZW9yLmNvbVwiLFxyXG4gICAgfSk7XHJcblxyXG4gICAgYXdhaXQgaW5zZXJ0TGluayh7XHJcbiAgICAgIHRpdGxlOiBcIkRpc2N1c3Npb25zXCIsXHJcbiAgICAgIHVybDogXCJodHRwczovL2ZvcnVtcy5tZXRlb3IuY29tXCIsXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIC8vIFdlIHB1Ymxpc2ggdGhlIGVudGlyZSBMaW5rcyBjb2xsZWN0aW9uIHRvIGFsbCBjbGllbnRzLlxyXG4gIC8vIEluIG9yZGVyIHRvIGJlIGZldGNoZWQgaW4gcmVhbC10aW1lIHRvIHRoZSBjbGllbnRzXHJcbiAgTWV0ZW9yLnB1Ymxpc2goXCJsaW5rc1wiLCBmdW5jdGlvbiAoKSB7XHJcbiAgICByZXR1cm4gTGlua3NDb2xsZWN0aW9uLmZpbmQoKTtcclxuICB9KTtcclxufSk7XHJcbiJdfQ==
